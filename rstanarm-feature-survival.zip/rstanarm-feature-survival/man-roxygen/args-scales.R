#' @param <%= scalesArg %> A character string passed to the \code{scales}  
#'   argument of \code{\link[ggplot2]{facet_wrap}} when plotting the 
#'   longitudinal trajectory for more than one individual.
