#' @return A \link[=stanreg-objects]{stanreg} object is returned 
#' for \code{<%= fun %>}.
