#' @param max_treedepth A positive integer specifying the maximum treedepth 
#'   for the non-U-turn sampler. See the \code{control} argument in 
#'   \code{\link[rstan]{stan}}.
