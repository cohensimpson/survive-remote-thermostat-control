#' @param remove_stub Logical specifying whether to remove the string identifying 
#'    the submodel (e.g. \code{y1|}, \code{y2|}, \code{Long1|}, \code{Long2|},
#'    \code{Event|}) from each of the parameter names.
