#' @param <%= cigeomArg %> Optional arguments passed to 
#'   \code{\link[ggplot2]{geom_ribbon}} and used to control features
#'   of the plotted interval limits. They should be supplied as a named list.
