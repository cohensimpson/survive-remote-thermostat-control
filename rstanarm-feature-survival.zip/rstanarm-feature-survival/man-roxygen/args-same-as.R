#' @param <%= sameargs %> Same as \code{\link[<%= pkg %>]{<%= pkgfun %>}}.
