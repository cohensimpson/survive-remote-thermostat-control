#' @references 
#' Bates, D., Maechler, M., Bolker, B., and Walker, S. (2015). Fitting linear 
#' mixed-Effects models using lme4. \emph{Journal of Statistical Software}.
#' 67(1), 1--48.
