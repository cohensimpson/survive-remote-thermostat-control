#' @references 
#' Stan Development Team. \emph{Stan Modeling Language Users Guide and
#' Reference Manual.} \url{https://mc-stan.org/users/documentation/}.
