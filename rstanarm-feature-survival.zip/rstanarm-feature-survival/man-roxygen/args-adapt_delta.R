#' @param adapt_delta Only relevant if \code{algorithm="sampling"}. See 
#'   the \link{adapt_delta} help page for details.
