#' @param <%= sameargs2 %> Same as \code{\link[<%= pkg %>]{<%= pkgfun %>}}.
