#' @param <%= stanregArg %> A fitted model object returned by one of the 
#'   \pkg{rstanarm} modeling functions. See \code{\link{stanreg-objects}}.
