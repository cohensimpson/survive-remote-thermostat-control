#' @param ids An optional vector providing a subset of subject IDs for whom 
#'   the predicted curves should be plotted.
