#' @param <%= stanregArg %> A fitted model object returned by the 
#'   \code{\link{stan_surv}} or \code{\link{stan_jm}} modelling function. 
#'   See \code{\link{stanreg-objects}}.
