#' @param <%= mArg %> Integer specifying the number or name of the submodel
