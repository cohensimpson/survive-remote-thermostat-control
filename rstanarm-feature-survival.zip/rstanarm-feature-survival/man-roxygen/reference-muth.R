#' @references
#' Muth, C., Oravecz, Z., and Gabry, J. (2018)
#' User-friendly Bayesian regression modeling: A tutorial with rstanarm and shinystan.
#' \emph{The Quantitative Methods for Psychology}. 14(2), 99--119.
#' \url{https://www.tqmp.org/RegularArticles/vol14-2/p099/p099.pdf}
