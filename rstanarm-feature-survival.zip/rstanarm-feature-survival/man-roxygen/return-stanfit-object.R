#' @return A \link[=stanfit-class]{stanfit} object (or a slightly modified 
#'   stanfit object) is returned if \code{<%= fitfun %>} is called directly.
