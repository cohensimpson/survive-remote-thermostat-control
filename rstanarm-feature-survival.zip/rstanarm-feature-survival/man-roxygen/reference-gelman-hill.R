#' @references Gelman, A. and Hill, J. (2007). \emph{Data Analysis Using
#'   Regression and Multilevel/Hierarchical Models.} Cambridge University Press,
#'   Cambridge, UK. <%= armRef %>
