#' @param <%= labsArg %> An optional axis label passed to 
#'   \code{\link[ggplot2]{labs}}.
