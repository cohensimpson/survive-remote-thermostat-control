#' @param <%= stanmvregArg %> A fitted model object returned by one of the 
#'   multivariate \pkg{rstanarm} modelling functions. See 
#'   \code{\link{stanreg-objects}}.
