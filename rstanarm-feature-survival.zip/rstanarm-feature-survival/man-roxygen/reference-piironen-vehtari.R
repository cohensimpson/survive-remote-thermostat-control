#' @references 
#' Piironen, J., and Vehtari, A. (2017). Sparsity information and regularization
#' in the horseshoe and other shrinkage priors. \url{https://arxiv.org/abs/1707.01694}
