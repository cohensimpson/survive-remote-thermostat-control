#' @references 
#' Gelman, A. and Carlin, J. (2014). Beyond power calculations:
#' assessing Type S (sign) and Type M (magnitude) errors. \emph{Perspectives on
#' Psychological Science}. 9(6), 641--51.
